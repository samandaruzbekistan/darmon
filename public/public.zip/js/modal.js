let modal = document.querySelector('.modal')

const toggle = () => {
    modal.classList.toggle('open')
    body.classList.toggle('openModal')
    containerDiv.classList.toggle('openModal')
}
