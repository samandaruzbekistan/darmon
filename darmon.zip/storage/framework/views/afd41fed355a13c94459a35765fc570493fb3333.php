<?php $__env->startSection('blocks'); ?>
    active
<?php $__env->stopSection(); ?>
<?php $__env->startSection('section'); ?>
    <div class="container-fluid pt-4 px-4">
        <div class="row g-4">
            <?php $__currentLoopData = $blocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-6 col-xl-3">
                    <div
                        class="bg-light rounded d-flex align-items-center justify-content-between p-4"
                    >
                        <h1 class="text-primary"><?php echo e($item->letter); ?></h1>
                        <a href="#">
                            <div class="ms-3">
                                <p class="mb-2"><?php echo e($item->name); ?></p>
                                <h6 class="mb-0">Umumiy palatalar soni: <span><?php echo e($item->ward_count); ?></span></h6>
                                <div class="progress mt-2" role="progressbar" aria-label="Example with label" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
                                    <div class="progress-bar" style="width: <?php echo e($item->filled_prosent); ?>%"><?php echo e($item->filled_prosent); ?>%</div>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <a href="<?php echo e(route('block_export')); ?>" class="btn btn-success mt-3"><i class="fas fa-file-excel"></i> Excel export</a>
    </div>


    <!-- ADD BLOG MODAL -->
    <div class="modal fade" id="addBlog" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Yangi blog qo'shish</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="<?php echo e(route('add_block')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="input1" class="form-label">Blog harfi</label>
                            <input type="text" required name="block_letter" class="form-control" id="input1">
                        </div>
                        <div class="mb-3">
                            <label for="input1" class="form-label">Blog nomi</label>
                            <input type="text" required name="block_name" class="form-control" id="input1">
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Bekor qilish</button>
                            <button type="submit" class="btn btn-primary">Saqlash</button>
                        </div>
                    </div>
                </form>













            </div>
        </div>
    </div>

    <!-- EDIT BLOG MODAL -->





























































    <!-- Back to Top -->
    <!-- <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a> -->

    <!-- Add new blog button -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top" data-bs-toggle="modal" data-bs-target="#addBlog"><i class="bi bi-plus"></i></a>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\darmon\resources\views/admin/blocks.blade.php ENDPATH**/ ?>