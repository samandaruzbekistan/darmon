<?php $__env->startSection('home'); ?>
    active
<?php $__env->stopSection(); ?>
<?php $__env->startSection('section'); ?>
        <!-- Sale & Revenue Start -->
        <div class="container-fluid pt-4 px-4">
            <div class="row g-4">
                <div class="col-sm-6 col-xl-3">
                    <a href="./sections.html">
                        <div
                            class="bg-light rounded d-flex align-items-center justify-content-between p-4"
                        >
                            <i class="fa fa-hospital fa-3x text-primary"></i>
                            <div class="ms-3">
                                <p class="mb-2">BO'SH O'RINLAR</p>
                                <h6 class="mb-0">Umumiy bo'sh o'rinlar miqdori: <span><?php echo e($data['empty_spaces']); ?></span></h6>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-sm-6 col-xl-3">
                    <a href="./patients.html">
                        <div
                            class="bg-light rounded d-flex align-items-center justify-content-between p-4"
                        >
                            <i class="fa fa-users fa-3x text-primary"></i>
                            <div class="ms-3">
                                <p class="mb-2">BEMORLAR</p>
                                <h6 class="mb-0">Umumiy bemorlar miqdori: <span><?php echo e($data['users']); ?></span></h6>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-sm-6 col-xl-3">
                    <a href="./doctors.html">
                        <div
                            class="bg-light rounded d-flex align-items-center justify-content-between p-4"
                        >
                            <i class="fa fa-user-md fa-3x text-primary"></i>
                            <div class="ms-3">
                                <p class="mb-2">SHIFOKORLAR</p>
                                <h6 class="mb-0">Umumiy shifokorlar miqdori: <span><?php echo e($data['doctors']); ?></span></h6>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-sm-6 col-xl-3">
                    <a href="#">
                        <div
                            class="bg-light rounded d-flex align-items-center justify-content-between p-4"
                        >
                            <i class="fas fa-sms fa-3x text-primary"></i>
                            <div class="ms-3">
                                <p class="mb-2">SMS xizmati</p>
                                <h6 class="mb-0">Bemorlarga sms jo'natish</h6>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
        <!-- Sale & Revenue End -->
        <!-- Add Patient Start -->
        <div class="container-fluid pt-4 px-4">
            <div class="bg-light text-center rounded p-4">
                <div class="d-flex align-items-center justify-content-between mb-4">
                    <h6 class="mb-0">Kunduzgi ko'rik</h6>
                    <button class="btn btn-success">Ko'rikdan o'tkazildi</button>
                </div>
                <div class="table-responsive">
                    <table
                        class="table text-start align-middle table-bordered table-hover mb-0"
                    >
                        <thead>
                        <tr class="text-dark">
                            <th scope="col">
                                Ko'rik
                            </th>
                            <th scope="col">Bemor</th>
                            <th scope="col">Doctor</th>
                            <th scope="col">Blok</th>
                            <th scope="col">Palata</th>
                            <th scope="col">Holat</th>
                            <th scope="col">Sabab</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $data['day']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $process): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($process->type == 1): ?>
                                <tr>
                                    <td><input class="form-check-input" type="checkbox" /></td>
                                    <td><?php echo e($process->user_name); ?></td>
                                    <td><?php echo e($process->doctor); ?></td>
                                    <td><?php echo e($process->block_letter); ?></td>
                                    <td><?php echo e($process->ward_number); ?></td>
                                    <?php if($process->status == 1): ?>
                                        <td><i class="bi bi-check2 h4 text-success"></i></td>
                                    <?php else: ?>
                                        <td><i class="bi bi-x h4 text-danger"></i></td>
                                    <?php endif; ?>
                                        <td><?php echo e($process->reason); ?></td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>



        <div class="container-fluid pt-4 px-4">
            <div class="bg-light text-center rounded p-4">
                <div class="d-flex align-items-center justify-content-between mb-4">
                    <h6 class="mb-0">Kechgi ko'rik</h6>
                    <button class="btn btn-success">Ko'rikdan o'tkazildi</button>
                </div>
                <div class="table-responsive">
                    <table
                        class="table text-start align-middle table-bordered table-hover mb-0"
                    >
                        <thead>
                        <tr class="text-dark">
                            <th scope="col">
                                Ko'rik
                            </th>
                            <th scope="col">Bemor</th>
                            <th scope="col">Doctor</th>
                            <th scope="col">Blok</th>
                            <th scope="col">Palata</th>
                            <th scope="col">Holat</th>
                            <th scope="col">Sabab</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $data['day']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $process): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($process->type == 2): ?>
                                <tr>
                                    <td><input class="form-check-input" type="checkbox" /></td>
                                    <td><?php echo e($process->user_name); ?></td>
                                    <td><?php echo e($process->doctor); ?></td>
                                    <td><?php echo e($process->block_letter); ?></td>
                                    <td><?php echo e($process->ward_number); ?></td>
                                    <?php if($process->status == 1): ?>
                                        <td><i class="bi bi-check2 h4 text-success"></i></td>
                                    <?php else: ?>
                                        <td><i class="bi bi-x h4 text-danger"></i></td>
                                    <?php endif; ?>
                                        <td><?php echo e($process->reason); ?></td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <!-- Add Patient End -->























































































    </div>
    <!-- Content End -->

    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"
    ><i class="bi bi-arrow-up"></i
        ></a>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\darmon\resources\views/admin/home.blade.php ENDPATH**/ ?>