<?php $__env->startSection('wards'); ?>
    active
<?php $__env->stopSection(); ?>
<?php $__env->startSection('section'); ?>
    <div class="container-fluid pt-4 px-4">
        <?php if((session()->has('backData')) and (session('backData') == 1)): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong>Muvaffaqiyatli!</strong> Yangi palata tizimga kiritildi.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
            <div class="row mb-3">
                <div class="col">
                    <select id="block_id" name="block_id" class="form-select" aria-label="Default select example">
                        <option value="all">Barcha blocklar</option>
                        <?php $__currentLoopData = $blocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($block->id); ?>"><?php echo e($block->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col">
                    <select id="type" name="type" class="form-select" aria-label="Default select example">
                        <option value="all">Xona turi: Barcha</option>
                        <option value="standard">Standart</option>
                        <option value="pollux">Pol lux</option>
                        <option value="lux">Lux</option>
                    </select>
                </div>
                <div class="col">
                    <select id="status" name="status" class="form-select" aria-label="Default select example">
                        <option value="all">Xona holati: Barcha</option>
                        <option value="2">To'liq</option>
                        <option value="1">Chala to'lgan</option>
                        <option value="0">Bo'sh</option>
                    </select>
                </div>
                <div class="col">
                    <button type="button" id="tugma" class="btn btn-primary">Qo'llash</button>
                </div>
            </div>

        <div class="row g-4" id="wards">
            <?php if(count($wards) > 0): ?>
                <?php $__currentLoopData = $wards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-6 col-xl-3" style="cursor: pointer">
                    <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                        <h1 class="text-primary"><?php echo e($item->number); ?></h1>
                        <div class="ms-3">
                            <p class="mb-2">Palata</p>
                            <h6 class="mb-0">Bemorlar soni: <span><?php echo e($item->users_count); ?></span></h6>
                            <div class="progress mt-2" role="progressbar" aria-label="Example with label" aria-valuenow="<?php echo e($item->users_count*100/$item->space_count); ?>" aria-valuemin="0" aria-valuemax="100">
                                <div class="progress-bar" style="width: <?php echo e($item->users_count*100/$item->space_count); ?>%"><?php echo e($item->users_count*100/$item->space_count); ?>%</div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <h4 class="text-center mt-5">Palatalar mavjud emas!</h4>
            <?php endif; ?>
        </div>
    </div>


    <!-- ADD BLOG MODAL -->
    <div class="modal fade" id="addBlog" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Yangi palata qo'shish</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="<?php echo e(route('add_ward')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="input1" class="form-label">Palata raqami</label>
                            <input type="number" required name="number" class="form-control" id="input1">
                        </div>
                        <div class="mb-3">
                            <label for="input1" class="form-label">Joylar soni</label>
                            <input type="number" required name="space_count" class="form-control" id="input1">
                        </div>
                        <div class="mb-3">
                            <label for="input1" class="form-label">Palata turi </label>
                            <select id="type" name="type" class="form-select" aria-label="Default select example">
                                <option value="standard">Standard</option>
                                <option value="pollux">Pol lux</option>
                                <option value="lux">Lux</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="input1" class="form-label">Blog </label>
                            <select id="block_id" name="block_id" class="form-select" aria-label="Default select example">
                                <?php $__currentLoopData = $blocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($block->id); ?>"><?php echo e($block->letter); ?> blok <?php echo e($block->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Bekor qilish</button>
                            <button type="submit" class="btn btn-primary">Saqlash</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- EDIT BLOG MODAL -->
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    


    <!-- Back to Top -->
    <!-- <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a> -->

    <!-- Add new blog button -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top" data-bs-toggle="modal" data-bs-target="#addBlog"><i class="bi bi-plus"></i></a>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function() {
            $('#tugma').on('click', function () {
                let block_id = $('#block_id').val();
                let type = $('#type').val();
                let status = $('#status').val();

                $.ajax({
                    url: '<?php echo e(route('admin_wards_with_params')); ?>',
                    type: 'GET',
                    data: {block_id: block_id, type:type, status:status},
                    success: function (response) {
                        let wardsContainer = $('#wards');
                        wardsContainer.empty();
console.log(response)
                        $.each(response, function(key, item) {
                            let wardItem = `
                  <div class="col-sm-6 col-xl-3">
                     <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                        <h1 class="text-primary"> ${item.number}</h1>
                        <a href="./a-section.html">
                           <div class="ms-3">
                              <p class="mb-2">Palata</p>
                              <h6 class="mb-0">Bemorlar soni: <span> ${item.users_count}</span></h6>
                              <div class="progress mt-2" role="progressbar" aria-label="Example with label" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
                                 <div class="progress-bar" style="width: ${item.users_count*100/item.space_count}%">${item.users_count*100/item.space_count}%</div>
                              </div>
                           </div>
                        </a>
                     </div>
                  </div>
               `;
                            wardsContainer.append(wardItem);
                        });
                    },
                    error: function (xhr, status, error) {
                        console.log(error);
                    }
                });
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\darmon\resources\views/admin/wards.blade.php ENDPATH**/ ?>