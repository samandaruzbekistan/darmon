
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Control panel</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600;700&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="<?php echo e(asset('lib/owlcarousel/assets/owl.carousel.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css')); ?>" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="<?php echo e(asset('css/style-admin.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/cards-admin.css')); ?>" rel="stylesheet">
</head>

<body>
<div class="container-fluid position-relative bg-white d-flex p-0">
    <!-- Spinner Start -->
    <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
            <span class="sr-only">Yuklanmoqda...</span>
        </div>
    </div>
    <!-- Spinner End -->


    <!-- Sidebar Start -->
    <div class="sidebar pe-4 pb-3">
        <nav class="navbar bg-light navbar-light">
            <a href="<?php echo e(route('admin_home')); ?>" class="navbar-brand mx-4 mb-3">
                <h3 class="text-primary"><i class="fa fa-hashtag me-2"></i>DARMON</h3>
            </a>
            <div class="navbar-nav w-100">
                <a href="<?php echo e(route('admin_home')); ?>" class="nav-item nav-link <?php echo $__env->yieldContent('home'); ?>"><i class="fa fa-tachometer-alt me-2"></i>Bosh menu</a>

                <a href="<?php echo e(route('admin_blocks')); ?>" class="nav-item nav-link  <?php echo $__env->yieldContent('blocks'); ?>"><i class="fa fa-table me-2"></i>Bloklar</a>
                <a href="<?php echo e(route('admin_wards')); ?>" class="nav-item nav-link  <?php echo $__env->yieldContent('wards'); ?>"><i class="fas fa-th-large me-2"></i>Palatalar</a>
                <a href="<?php echo e(route('doctors')); ?>" class="nav-item nav-link <?php echo $__env->yieldContent('doctors'); ?>"><i class="fas fa-user-md me-2"></i>Shifokorlar</a>
                <a href="<?php echo e(route('receptions')); ?>" class="nav-item nav-link <?php echo $__env->yieldContent('reception'); ?>"><i class="fas fa-sign-out-alt me-2"></i>Qabulxona</a>
                <a href="<?php echo e(route('nurses')); ?>" class="nav-item nav-link <?php echo $__env->yieldContent('nurse'); ?>"><i class="fas fa-notes-medical me-2"></i>Hamshiralar</a>
                <a href="<?php echo e(route('sms')); ?>" class="nav-item nav-link <?php echo $__env->yieldContent('sms'); ?>"><i class="fas fa-sms me-2"></i>SMS xizmati</a>

                <a href="chart.html" class="nav-item nav-link"><i class="fa fa-chart-bar me-2"></i>Charts</a>
            </div>
        </nav>
    </div>
    <!-- Sidebar End -->

    <!-- Content Start -->
    <div class="content">
        <!-- Navbar Start -->
        <nav class="navbar navbar-expand bg-light navbar-light sticky-top px-4 py-0">
            <a href="index.html" class="navbar-brand d-flex d-lg-none me-4">
                <h2 class="text-primary mb-0"><i class="fa fa-hashtag"></i></h2>
            </a>
            <a href="#" class="sidebar-toggler flex-shrink-0">
                <i class="fa fa-bars"></i>
            </a>
            <form class="d-none d-md-flex ms-4">
                <input class="form-control border-0" type="search" placeholder="Qidiruv...">
            </form>
            <div class="navbar-nav align-items-center ms-auto">
                <div class="nav-item">
                    <a
                        href="#"
                        class="nav-link active"
                    >
                        <i class="fa fa-hospital"></i>

                    </a>
                </div>
                <a href="<?php echo e(route('admin_logout')); ?>">
                    <button class="btn btn-primary mx-2">
                        <i class="fa fa-sign-out-alt"></i>
                        Chiqish
                    </button>
                </a>
            </div>
        </nav>
        <!-- Navbar End -->



        <?php echo $__env->yieldContent('section'); ?>


        </div>

    </div>
    <!-- Content End -->

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo e(asset('lib/chart/chart.min.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/easing/easing.min.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/waypoints/waypoints.min.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/owlcarousel/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/tempusdominus/js/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/tempusdominus/js/moment-timezone.min.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js')); ?>"></script>

    <?php echo $__env->yieldContent('js'); ?>

    <!-- Template Javascript -->
    <script src="<?php echo e(asset('js/main.js')); ?>"></script>
</body>

</html>
<?php /**PATH C:\OpenServer\domains\darmon\resources\views/admin/header.blade.php ENDPATH**/ ?>